package model;

public class Client {
	
	private String refcra_client_nom;

	public String getRefcra_client_nom() {
		return refcra_client_nom;
	}

	public void setRefcra_client_nom(String refcra_client_nom) {
		this.refcra_client_nom = refcra_client_nom;
	}

	public Client(String refcra_client_nom) {
		super();
		this.refcra_client_nom = refcra_client_nom;
	}

	public Client() {
		
	}
	
	
	
	
	
	
	

}
