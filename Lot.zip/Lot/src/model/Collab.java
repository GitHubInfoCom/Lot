package model;

import java.util.Date;

public class Collab {
	
	private String nom;
	private String prenom;
	private String refcra_ref_interne;
	private String refcra_client_nom;
	private double nbre_jour_travailles;
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public String getRefcra_ref_interne() {
		return refcra_ref_interne;
	}
	public void setRefcra_ref_interne(String refcra_ref_interne) {
		this.refcra_ref_interne = refcra_ref_interne;
	}
	public String getRefcra_client_nom() {
		return refcra_client_nom;
	}
	public void setRefcra_client_nom(String refcra_client_nom) {
		this.refcra_client_nom = refcra_client_nom;
	}
	public double getNbre_jour_travailles() {
		return nbre_jour_travailles;
	}
	public void setNbre_jour_travailles(double nbre_jour_travailles) {
		this.nbre_jour_travailles = nbre_jour_travailles;
	}
	public Collab(String nom, String prenom, String refcra_ref_interne, String refcra_client_nom,
			double nbre_jour_travailles) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.refcra_ref_interne = refcra_ref_interne;
		this.refcra_client_nom = refcra_client_nom;
		this.nbre_jour_travailles = nbre_jour_travailles;
	}
	
	
	public Collab() {
		
	}
	
	
	
	
	
	
	

}
