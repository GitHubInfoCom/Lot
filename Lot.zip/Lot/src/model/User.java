package model;

import java.util.Date;

/**
 * User.java
 * This is a model class represents a User entity
 * @author Ramesh Fadatare
 *
 */
public class User {
	
	private String noms;
	private String prenom;
	private String idReferenceCra;
	private String referenceCraInterne;
	private String referenceCraClient_ref;
	private Date periode_date;
	private double nbre_jour_travailles;
	
	public User() {
	}
	

	public User(String noms, String prenom, String idReferenceCra, String referenceCraInterne,
		String referenceCraClient_ref, Date periode_date, double nbre_jour_travailles) {
	super();
	this.noms = noms;
	this.prenom = prenom;
	this.idReferenceCra = idReferenceCra;
	this.referenceCraInterne = referenceCraInterne;
	this.referenceCraClient_ref = referenceCraClient_ref;
	this.periode_date = periode_date;
	this.nbre_jour_travailles = nbre_jour_travailles;
    }


	public String getNoms() {
		return noms;
	}


	public void setNoms(String noms) {
		this.noms = noms;
	}


	public String getPrenom() {
		return prenom;
	}


	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}


	public String getIdReferenceCra() {
		return idReferenceCra;
	}


	public void setIdReferenceCra(String idReferenceCra) {
		this.idReferenceCra = idReferenceCra;
	}


	public String getReferenceCraInterne() {
		return referenceCraInterne;
	}


	public void setReferenceCraInterne(String referenceCraInterne) {
		this.referenceCraInterne = referenceCraInterne;
	}


	public String getReferenceCraClient_ref() {
		return referenceCraClient_ref;
	}


	public void setReferenceCraClient_ref(String referenceCraClient_ref) {
		this.referenceCraClient_ref = referenceCraClient_ref;
	}


	public Date getPeriode_date() {
		return periode_date;
	}


	public void setPeriode_date(Date periode_date) {
		this.periode_date = periode_date;
	}


	public double getNbre_jour_travailles() {
		return nbre_jour_travailles;
	}


	public void setNbre_jour_travailles(double nbre_jour_travailles) {
		this.nbre_jour_travailles = nbre_jour_travailles;
	}


}
