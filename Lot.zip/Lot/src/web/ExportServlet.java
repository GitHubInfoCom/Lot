package web;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import dao.UserDAO;
import model.User;
    
/*import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;*/

public class ExportServlet extends HttpServlet
{
   public void doGet(HttpServletRequest request, 
    HttpServletResponse response)
      throws ServletException, IOException
   {
    OutputStream out = null;
    try
    {
 
     response.setContentType("application/vnd.ms-excel");
 
     response.setHeader("Content-Disposition", 
    "attachment; filename=sampleName.xls");
     List<User> users = new ArrayList<User>();
     users=UserDAO.selectAllUsers();
     Workbook workbook = new XSSFWorkbook();
   Sheet sheet = workbook.createSheet("Contacts");

   Font headerFont = workbook.createFont();
  // headerFont.setBold(true);
   headerFont.setFontHeightInPoints((short) 12);
   headerFont.setColor(IndexedColors.CORNFLOWER_BLUE.getIndex());

   CellStyle headerCellStyle = workbook.createCellStyle();
   headerCellStyle.setFont(headerFont);
   
   String[] columns = {"noms", "prenom","idReferenceCra", "referenceCraInterne",
	          "referenceCraClient_ref", "periode_date", "nbre_jour_travailles"};

   // Create a Row
   Row headerRow = sheet.createRow(0);

   for (int i = 0; i < columns.length; i++) {
     Cell cell = headerRow.createCell(i);
     cell.setCellValue(columns[i]);
     cell.setCellStyle(headerCellStyle);
   }

   // Create Other rows and cells with contacts data
   int rowNum = 1;
   SimpleDateFormat formater = new SimpleDateFormat("dd/MM/yyyy");
   for (User user : users) {
	      Row row = sheet.createRow(rowNum++);
	      
	     // int sommmeTTMois= contact.getJanvier()+contact.getFeverier()+contact.getMars()+contact.getAvril();
	      
	      row.createCell(0).setCellValue(user.getNoms());
	      row.createCell(1).setCellValue(user.getPrenom());
	      row.createCell(2).setCellValue(user.getIdReferenceCra());
	      row.createCell(3).setCellValue(user.getReferenceCraInterne());
	      
	      
	      row.createCell(4).setCellValue(user.getReferenceCraClient_ref());
	      row.createCell(5).setCellValue(formater.format(user.getPeriode_date()));
	      row.createCell(6).setCellValue(user.getNbre_jour_travailles());
	      
	      
	      
	     // row.createCell(5).setCellValue(contact.sommePannier());
	    }

   // Resize all columns to fit the content size
   for (int i = 0; i < columns.length; i++) {
     sheet.autoSizeColumn(i);
   }

   // Write the output to a file
//   try {
//       FileOutputStream fileOut = new FileOutputStream("C:\\Users\\menad\\Desktop\\Excell\\ExelPresence.xlsx");
//       workbook.write(fileOut);
//       fileOut.close();
//   } catch (Exception e) {
//   System.out.println(e);
//   }
   
   try {
	   out = response.getOutputStream();
       workbook.write( out );
   } catch (Exception e)
    {
     throw new ServletException("Exception in Excel Sample Servlet", e);
    } finally
    {
     if (out != null)
      out.close();
    }
    }catch (Exception e)
   {
    throw new ServletException("Exception in Excel Sample Servlet", e);
   }
   }
  }
