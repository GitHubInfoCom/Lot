package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Client;
import model.Collab;
import model.User;

/**
 * AbstractDAO.java This DAO class provides CRUD database operations for the
 * table users in the database.
 * 
 * @author Ramesh Fadatare
 *
 */
public class UserDAO {
	private static String jdbcURL = "jdbc:mysql://localhost:3306/cuisine?characterEncoding=latin1&useConfigs=maxPerformance"; 
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "dadapoly08124";

	//private static final String INSERT_USERS_SQL= "INSERT INTO users" + "  (name, email, country) VALUES "
	//		+ " (?, ?, ?);";

	//private static final String SELECT_USER_BY_ID = "select id,name,email,country from users where id =?";
	
	
	private static final String SELECT_ALL_USERS =  "    select c.collab_id\r\n" + 
			"    , c.collab_nom\r\n" + 
			"    , c.collab_prenom\r\n" + 
			"        , a.fk_refcra_id\r\n" + 
			"        , r.refcra_ref_interne\r\n" + 
			"        , r.refcra_client_ref\r\n" + 
			"        , a.period_date\r\n" + 
			"        , sum(a.d01 + a.d02 + a.d03 + a.d04 + a.d05 + a.d06 + a.d07 + a.d08 + a.d09 \r\n" + 
			"    + a.d10 + a.d11 + a.d12 + a.d13 + a.d14 + a.d15 + a.d16 + a.d17 + a.d18 + a.d19 \r\n" + 
			"    + a.d20 + a.d21 + a.d22 + a.d23 + a.d24 + a.d25 + a.d26 + a.d27 + a.d28 + a.d29 \r\n" + 
			"    + a.d30 + a.d31) as 'nb_jours_travailles'\r\n" + 
			"    from activity a\r\n" + 
			"    inner join collab c on c.collab_id = a.fk_collab_id\r\n" + 
			"    inner join refcra r on r.refcra_id = a.fk_refcra_id\r\n" + 
			"    where a.period_date BETWEEN '2019-01-01' and '2019-12-31'\r\n" + 
			"    group by c.collab_id\r\n" + 
			"    , c.collab_nom\r\n" + 
			"    , c.collab_prenom\r\n" + 
			"        , a.fk_refcra_id\r\n" + 
			"        , r.refcra_ref_interne\r\n" + 
			"        , r.refcra_client_ref\r\n" + 
			"        , a.period_date\r\n" + 
			"";
	public static void selectDate(String annee) {
		
	}
	
	
	
	
	
	private static final String SELECT_ALL_Collabs =  "    select c.collab_id\r\n" + 
			"    , c.collab_nom\r\n" + 
			"    , c.collab_prenom\r\n" + 
			"        , a.fk_refcra_id\r\n" + 
			"        , r.refcra_ref_interne\r\n" + 
			"        , r.refcra_client_ref\r\n" + 
			"        , a.period_date\r\n" + 
			"        , sum(a.d01 + a.d02 + a.d03 + a.d04 + a.d05 + a.d06 + a.d07 + a.d08 + a.d09 \r\n" + 
			"    + a.d10 + a.d11 + a.d12 + a.d13 + a.d14 + a.d15 + a.d16 + a.d17 + a.d18 + a.d19 \r\n" + 
			"    + a.d20 + a.d21 + a.d22 + a.d23 + a.d24 + a.d25 + a.d26 + a.d27 + a.d28 + a.d29 \r\n" + 
			"    + a.d30 + a.d31) as 'nb_jours_travailles'\r\n" + 
			"    from activity a\r\n" + 
			"    inner join collab c on c.collab_id = a.fk_collab_id\r\n" + 
			"    inner join refcra r on r.refcra_id = a.fk_refcra_id\r\n" + 
			"    where a.period_date BETWEEN '2019-01-01' and '2019-12-31'\r\n" + 
			"    group by c.collab_id\r\n" + 
			"    , c.collab_nom\r\n" + 
			"    , c.collab_prenom\r\n" + 
			"        , a.fk_refcra_id\r\n" + 
			"        , r.refcra_ref_interne\r\n" + 
			"        , r.refcra_client_ref\r\n" + 
			"        , a.period_date\r\n" + 
			"";
			
	
	
	
	
	
	
	
	
	
	private static final String DELETE_USERS_SQL = "delete from users where id = ?;";
	private static final String UPDATE_USERS_SQL = "update users set name = ?,email= ?, country =? where id = ?;";
	
	private static final String SELECT_CLIENT =  "SELECT refcra_client_nom from refcra";

	public UserDAO() {
	}

	protected static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

/*	public void insertUser(User user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getName());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, user.getCountry());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}
*/
	/* public User selectUser(int id) {
		User user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String country = rs.getString("country");
				user = new User(id, name, email, country);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}
*/
	
	public static List<Collab> selectAllCollabs() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Collab> collabs = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_Collabs);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String nom = rs.getString("collab_nom");
				String prenom = rs.getString("collab_prenom");
				
				String refcra_ref_interne = rs.getString("refcra_ref_interne");
				String refcra_client_ref = rs.getString("refcra_client_ref");
				double nb_jours_travailles = rs.getDouble("nb_jours_travailles");
				
				collabs.add(new Collab(nom, prenom, refcra_ref_interne,refcra_client_ref,nb_jours_travailles));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return collabs;
	}
	
	
	public static List<User> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<User> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String nom = rs.getString("collab_nom");
				String prenom = rs.getString("collab_prenom");
				String refcra_id = rs.getString("fk_refcra_id");
				String refcra_ref_interne = rs.getString("refcra_client_ref");
				String refcra_client_ref = rs.getString("refcra_client_ref");
				Date period_date = rs.getDate("period_date");
				double nb_jours_travailles = rs.getDouble("nb_jours_travailles");
				
				users.add(new User(nom, prenom, refcra_id, refcra_ref_interne,refcra_client_ref,period_date,nb_jours_travailles));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	
	
	
	
	
	
	
	
	
	
	public static List<Client> selectAllClients() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Client> clients = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CLIENT);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String refcra_client_nom = rs.getString("refcra_client_nom");
				
				
				clients.add(new Client(refcra_client_nom));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return clients;
	}
	

/*	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}
*/
/*	public boolean updateUser(User user) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			statement.setString(1, user.getName());
			statement.setString(2, user.getEmail());
			statement.setString(3, user.getCountry());
			statement.setInt(4, user.getId());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
*/
	private static void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

}
